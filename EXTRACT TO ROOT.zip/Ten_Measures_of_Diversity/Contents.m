% In the name of ALLAH

% Prophet Mohammed said (ALLAH will help anyone helped his/her
% brother/sister) PBUH


% This code used to compute diversity measures between two or more classifiers
% This code implemented by Eng. Alaa Tharwat Abd El Monaaim - Egypt- TA in
% El Shorouk Academy
% engalaatharwat@hotmail.com  +201006091638


% Pairwise Diversity Measures
% 1-Q Test
% 2-Interater agreement k
% 3-Disagreement measure
% 4-Double Fault measure
% 5-Correlation Coefficient
% 
% NonPairwise Diversity Measures
% 1-Entropy
% 2-Interater agreement k
% 3-Kohavi�Wolpert Variance
% 4-The Measure of difficulty ?
% 5-Generalized Diversity
% 6-Coincident Failure Diversity
% 7-Q Test
% 8-Disagreement measure
% 9-Double Fault measure
% 10-Correlation Coefficient


